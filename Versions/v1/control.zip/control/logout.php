<?php

	ob_start();
	require_once('classes/DB.php');
	include('classes/class.admin.php');
	$user = new admin();
	if(!$user->isLoggedIn())
	{
		header('location:login.php');
	}
	admin::logout();
	header('location:/farmorders/control/login.php');
	ob_end_flush();

?>
	

